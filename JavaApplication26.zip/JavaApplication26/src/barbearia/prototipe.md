## Prototipo Figma
link: https://www.figma.com/design/p8G1pvEiMiOgJGJZ4ibnkU/Sem-t%C3%ADtulo?node-id=0-1&t=VKEP0Cgy7Wlb9HNN-1
