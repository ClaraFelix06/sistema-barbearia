package barbearia;

public class Barbearia {
   public static void main(String[] args) {
       
   }
}